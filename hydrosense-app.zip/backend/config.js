// config.js — central configuration, all secrets from environment variables
require('dotenv').config();

function required(name, fallbackDev) {
  const v = process.env[name];
  if (!v) {
    if (process.env.NODE_ENV === 'production') {
      throw new Error(`Missing required environment variable: ${name}. Set it in your .env file.`);
    }
    return fallbackDev;
  }
  return v;
}

module.exports = {
  PORT: process.env.PORT || 4000,
  JWT_SECRET: required('JWT_SECRET', 'dev-only-insecure-secret-change-me'),
  JWT_EXPIRES_IN: '4h',
  COOKIE_NAME: 'hs_session',
  NODE_ENV: process.env.NODE_ENV || 'development',
  AUTHORITY_EMAIL_DOMAIN: (process.env.AUTHORITY_EMAIL_DOMAIN || 'krct.ac.in').toLowerCase(),
  REPORT_CODE_PREFIX: process.env.REPORT_CODE_PREFIX || 'TRI',
  UPLOAD_DIR: process.env.UPLOAD_DIR || 'uploads',
  MAX_UPLOAD_MB: 8,
  ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY || '',
  SMTP_HOST: process.env.SMTP_HOST || '',
  SMTP_PORT: process.env.SMTP_PORT || 587,
  SMTP_USER: process.env.SMTP_USER || '',
  SMTP_PASS: process.env.SMTP_PASS || '',
  MAIL_FROM: process.env.MAIL_FROM || 'HydroSense <no-reply@hydrosense.local>',
  PUBLIC_BASE_URL: process.env.PUBLIC_BASE_URL || 'http://localhost:4000',
};
