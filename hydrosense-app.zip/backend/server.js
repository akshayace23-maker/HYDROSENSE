// server.js
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const path = require('path');
const rateLimit = require('express-rate-limit');

const config = require('./config');
require('./db/init'); // ensures schema exists on boot
const { csrfHeaderRequired } = require('./middleware/auth');
const { UPLOAD_ROOT } = require('./middleware/upload');

const authRoutes = require('./routes/auth');
const reportRoutes = require('./routes/reports');
const waterBodyRoutes = require('./routes/waterbodies');
const newsRoutes = require('./routes/news');

const app = express();

// Trust proxy (needed for correct rate-limiting / secure cookies behind a reverse proxy in production).
app.set('trust proxy', 1);

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      // unsafe-inline kept minimal and only for the small amount of inline styling in static pages;
      // scripts are all loaded from same-origin or pinned CDNs below.
      styleSrc: ["'self'", "'unsafe-inline'", 'https://unpkg.com', 'https://fonts.googleapis.com'],
      fontSrc: ["'self'", 'https://fonts.gstatic.com'],
      scriptSrc: ["'self'", 'https://unpkg.com', 'https://cdnjs.cloudflare.com'],
      imgSrc: ["'self'", 'data:', 'blob:', 'https://*.tile.openstreetmap.org'],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"],
      upgradeInsecureRequests: [],
    },
  },
  crossOriginResourcePolicy: { policy: 'same-site' },
}));

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));
app.use(cookieParser());

// Global rate limit as a baseline defense-in-depth on top of per-route limits.
app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, max: 300 }));

// CSRF defense-in-depth on all state-changing API calls (see middleware/auth.js).
app.use('/api', csrfHeaderRequired);

app.use('/api/auth', authRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/water-bodies', waterBodyRoutes);
app.use('/api/news', newsRoutes);

// Serve uploaded evidence photos. Directory listing is disabled by express.static by default,
// and filenames are server-generated random tokens (see middleware/upload.js), not user input.
app.use('/uploads', express.static(UPLOAD_ROOT, { dotfiles: 'deny', index: false }));

// Serve the frontend.
app.use(express.static(path.join(__dirname, '..', 'public')));

// Centralized error handler (keeps stack traces out of responses).
app.use((err, req, res, next) => {
  console.error(err);
  if (err.message && err.message.includes('Only JPEG')) {
    return res.status(400).json({ error: err.message });
  }
  res.status(500).json({ error: 'Something went wrong. Please try again.' });
});

app.listen(config.PORT, () => {
  console.log(`HydroSense server running on http://localhost:${config.PORT} [${config.NODE_ENV}]`);
});
