// routes/auth.js
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const { body, validationResult } = require('express-validator');

const db = require('../db/init');
const config = require('../config');
const { isAuthorityEmail } = require('../utils');
const { authRequired } = require('../middleware/auth');

const router = express.Router();

const LOCK_THRESHOLD = 5;
const LOCK_MINUTES = 15;

// Strict rate limits on auth endpoints to slow down credential stuffing / brute force.
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many attempts. Please try again later.' },
});

function setSessionCookie(res, user) {
  const token = jwt.sign(
    { id: user.id, role: user.role, name: user.name, email: user.email },
    config.JWT_SECRET,
    { expiresIn: config.JWT_EXPIRES_IN }
  );
  res.cookie(config.COOKIE_NAME, token, {
    httpOnly: true,
    secure: config.NODE_ENV === 'production',
    sameSite: 'strict',
    maxAge: 4 * 60 * 60 * 1000,
    path: '/',
  });
}

const registerValidators = [
  body('name').trim().isLength({ min: 2, max: 100 }).withMessage('Name must be 2-100 characters.'),
  body('email').trim().isEmail().normalizeEmail().withMessage('A valid email is required.'),
  body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters.'),
  body('role').isIn(['citizen', 'authority']).withMessage('Invalid role.'),
  body('phone').optional({ checkFalsy: true }).trim().isLength({ max: 20 }),
];

router.post('/register', authLimiter, registerValidators, (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ error: errors.array()[0].msg });

  const { name, email, password, role, phone } = req.body;

  if (role === 'authority' && !isAuthorityEmail(email)) {
    return res.status(400).json({
      error: `Authority accounts must use an official @${config.AUTHORITY_EMAIL_DOMAIN} email address.`,
    });
  }

  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) {
    return res.status(409).json({ error: 'An account with this email already exists.' });
  }

  const password_hash = bcrypt.hashSync(password, 12);
  const info = db
    .prepare('INSERT INTO users (role, name, email, password_hash, phone) VALUES (?,?,?,?,?)')
    .run(role, name, email, password_hash, phone || null);

  const user = { id: info.lastInsertRowid, role, name, email };
  setSessionCookie(res, user);
  res.status(201).json({ user: { id: user.id, role, name, email } });
});

router.post(
  '/login',
  authLimiter,
  [body('email').trim().isEmail().normalizeEmail(), body('password').isString().notEmpty()],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ error: 'Enter a valid email and password.' });

    const { email, password } = req.body;
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);

    // Generic error message regardless of which check fails, so we never
    // reveal whether an email is registered.
    const genericError = { error: 'Invalid email or password.' };

    if (!user) return res.status(401).json(genericError);

    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      return res.status(423).json({ error: 'Account temporarily locked due to failed attempts. Try again later.' });
    }

    const ok = bcrypt.compareSync(password, user.password_hash);
    if (!ok) {
      const attempts = user.failed_attempts + 1;
      let locked_until = null;
      if (attempts >= LOCK_THRESHOLD) {
        locked_until = new Date(Date.now() + LOCK_MINUTES * 60 * 1000).toISOString();
      }
      db.prepare('UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?').run(
        attempts, locked_until, user.id
      );
      return res.status(401).json(genericError);
    }

    db.prepare('UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?').run(user.id);
    setSessionCookie(res, user);
    res.json({ user: { id: user.id, role: user.role, name: user.name, email: user.email } });
  }
);

router.post('/logout', (req, res) => {
  res.clearCookie(config.COOKIE_NAME, { path: '/' });
  res.json({ ok: true });
});

router.get('/me', authRequired, (req, res) => {
  res.json({ user: req.user });
});

module.exports = router;
