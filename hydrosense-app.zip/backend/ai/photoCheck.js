// ai/photoCheck.js
//
// Optional, best-effort AI assistance: checks whether an uploaded photo
// plausibly shows a water body, lists possible visible indicators (never
// claims lab-confirmed pollution), and suggests one relevant follow-up
// question. Requires ANTHROPIC_API_KEY. If it's not set, or the call fails,
// callers must treat the result as "unchecked" and continue — AI is
// assistive only, never a gate on submission.
const fs = require('fs');
const config = require('../config');

const SYSTEM_PROMPT = `You assist a civic water-body complaint platform. You will see one photo a citizen submitted as evidence of a water-body issue.
Respond with ONLY a JSON object, no prose, no markdown fences, matching this shape:
{
  "relevance": "relevant" | "not_relevant" | "uncertain",
  "indicators": [array of 0-6 short strings from: "floating_garbage","dead_fish","algal_growth","excessive_vegetation","muddy_water","foam_froth","possible_discharge_outlet","waste_on_bank","erosion","encroachment_construction"],
  "note": "one short plain-language sentence, cautious, calling these 'possible visible indicators', never 'confirmed pollution'",
  "followup_question": "one short targeted question for the citizen based on what is visible, or empty string if none needed",
  "followup_options": [2-4 short answer choices for that question, or empty array]
}
If the image does not appear to show a water body or its surroundings (e.g. a selfie, an unrelated object, a person), set relevance to "not_relevant" and leave indicators empty.`;

async function checkPhoto(filePath, mimeType) {
  if (!config.ANTHROPIC_API_KEY) {
    return { relevance: 'unchecked', indicators: [], note: '', followup_question: '', followup_options: [] };
  }
  try {
    const base64 = fs.readFileSync(filePath).toString('base64');
    const resp = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': config.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 500,
        system: SYSTEM_PROMPT,
        messages: [
          {
            role: 'user',
            content: [
              { type: 'image', source: { type: 'base64', media_type: mimeType, data: base64 } },
              { type: 'text', text: 'Assess this water-body report photo.' },
            ],
          },
        ],
      }),
    });
    const data = await resp.json();
    const text = (data.content || []).map((b) => b.text || '').join('');
    const clean = text.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(clean);
    return {
      relevance: parsed.relevance || 'uncertain',
      indicators: Array.isArray(parsed.indicators) ? parsed.indicators.slice(0, 6) : [],
      note: parsed.note || '',
      followup_question: parsed.followup_question || '',
      followup_options: Array.isArray(parsed.followup_options) ? parsed.followup_options.slice(0, 4) : [],
    };
  } catch (e) {
    console.error('[ai photo check failed]', e.message);
    return { relevance: 'unchecked', indicators: [], note: '', followup_question: '', followup_options: [] };
  }
}

module.exports = { checkPhoto };
