// middleware/auth.js
const jwt = require('jsonwebtoken');
const config = require('../config');

// Reads the httpOnly session cookie, verifies the JWT, attaches req.user.
function authRequired(req, res, next) {
  const token = req.cookies ? req.cookies[config.COOKIE_NAME] : null;
  if (!token) return res.status(401).json({ error: 'Not authenticated.' });
  try {
    const payload = jwt.verify(token, config.JWT_SECRET);
    req.user = payload; // { id, role, name, email }
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Session expired or invalid. Please log in again.' });
  }
}

// Optional auth: attaches req.user if a valid cookie is present, but never blocks.
function authOptional(req, res, next) {
  const token = req.cookies ? req.cookies[config.COOKIE_NAME] : null;
  if (token) {
    try {
      req.user = jwt.verify(token, config.JWT_SECRET);
    } catch (e) { /* ignore invalid token for optional auth */ }
  }
  next();
}

function requireRole(role) {
  return (req, res, next) => {
    if (!req.user || req.user.role !== role) {
      return res.status(403).json({ error: 'You do not have permission to perform this action.' });
    }
    next();
  };
}

// Lightweight CSRF mitigation for cookie-based auth: since the JWT lives in an
// httpOnly, SameSite=Strict cookie, cross-site requests cannot carry it in
// modern browsers. As defense-in-depth we also require a custom header on all
// state-changing requests, which a genuine cross-site form post cannot set.
function csrfHeaderRequired(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  if (req.get('X-Requested-With') !== 'HydroSense') {
    return res.status(403).json({ error: 'Request blocked (missing required header).' });
  }
  next();
}

module.exports = { authRequired, authOptional, requireRole, csrfHeaderRequired };
