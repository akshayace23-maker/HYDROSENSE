// middleware/upload.js
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');
const fs = require('fs');
const config = require('../config');

const UPLOAD_ROOT = path.join(__dirname, '..', config.UPLOAD_DIR);
fs.mkdirSync(UPLOAD_ROOT, { recursive: true });

const ALLOWED_MIME = new Set(['image/jpeg', 'image/png', 'image/webp']);
const ALLOWED_EXT = new Set(['.jpg', '.jpeg', '.png', '.webp']);

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_ROOT),
  filename: (req, file, cb) => {
    // Never trust the client-supplied filename: generate a random name and
    // keep only a whitelisted extension, which prevents path traversal and
    // double-extension tricks (e.g. "shell.php.jpg").
    const ext = path.extname(file.originalname).toLowerCase();
    const safeExt = ALLOWED_EXT.has(ext) ? ext : '.jpg';
    cb(null, `${Date.now()}-${crypto.randomBytes(8).toString('hex')}${safeExt}`);
  },
});

function fileFilter(req, file, cb) {
  if (!ALLOWED_MIME.has(file.mimetype)) {
    return cb(new Error('Only JPEG, PNG, or WEBP images are allowed.'));
  }
  cb(null, true);
}

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: config.MAX_UPLOAD_MB * 1024 * 1024, files: 6 },
});

module.exports = { upload, UPLOAD_ROOT };
