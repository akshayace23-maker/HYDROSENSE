// js/api.js — shared fetch wrapper
const api = {
  async request(method, url, body, isForm) {
    const opts = {
      method,
      credentials: 'include',
      headers: { 'X-Requested-With': 'HydroSense' },
    };
    if (body && !isForm) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    } else if (body && isForm) {
      opts.body = body; // FormData sets its own content-type
    }
    const res = await fetch(url, opts);
    let data = null;
    try { data = await res.json(); } catch (e) { /* no body */ }
    if (!res.ok) {
      throw new Error((data && data.error) || `Request failed (${res.status})`);
    }
    return data;
  },
  get(url) { return this.request('GET', url); },
  post(url, body) { return this.request('POST', url, body, false); },
  postForm(url, formData) { return this.request('POST', url, formData, true); },
};

async function currentUser() {
  try {
    const data = await api.get('/api/auth/me');
    return data.user;
  } catch (e) {
    return null;
  }
}

function requireAuth(role) {
  return currentUser().then((user) => {
    if (!user || (role && user.role !== role)) {
      window.location.href = '/login.html';
      return null;
    }
    return user;
  });
}

function statusLabel(s) {
  return (s || '').replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

function fmtDate(d) {
  try { return new Date(d + 'Z').toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }); }
  catch (e) { return d; }
}
