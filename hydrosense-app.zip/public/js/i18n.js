// js/i18n.js — minimal, dependency-free i18n. Architecture is ready for more
// Indian regional languages: just add another key to DICT and a button.
const DICT = {
  en: {
    nav_map: 'GIS Map', nav_news: 'Water-Body News', nav_track: 'Track a Report',
    nav_waterbodies: 'Water Bodies', nav_about: 'About', nav_faq: 'FAQ',
    page_dashboard: 'My reports', page_track: 'Track a report', page_waterbodies: 'Water bodies',
    page_news: 'Latest water-body news', page_about: 'About', page_faq: 'Frequently asked questions',
    empty_reports: "You haven't submitted any reports yet.",
    hero_tag: 'Citizen–government water protection network',
    hero_h1_1: 'See It. Report It.', hero_h1_2: 'Protect It.',
    hero_lead: 'HydroSense connects citizens and authorities to monitor, protect and restore local water bodies — from a phone-camera observation to verified environmental action.',
    cta_report: 'Report a Water Issue', cta_explore: 'Explore Water Bodies', cta_track: 'Track a Report',
    step1_t: 'Observe', step1_d: 'Notice a visible problem at a pond, lake, river or tank.',
    step2_t: 'Report', step2_d: 'Photo, location and what you saw — two minutes, no jargon.',
    step3_t: 'Verify', step3_d: 'Nearby citizens can confirm with "I See This Too."',
    step4_t: 'Act', step4_d: 'Authorities inspect, intervene, and document before/after.',
    report_title: 'Report a water-body issue',
    report_step1: '1 · Water body', report_step2: '2 · Photo evidence', report_step3: '3 · What you observed', report_step4: '4 · Review & submit',
    field_wb_type: 'Water body type', field_wb_name: 'Water body name', field_location: 'Location',
    field_use_location: '📍 Use my current location', field_address: 'Approximate address / landmark (optional)',
    field_photos: 'Photo evidence', field_observed: 'What did you observe? (select all that apply)',
    field_notes: 'Anything else you noticed?', field_anon: 'Report anonymously',
  },
  ta: {
    nav_map: 'நிலப்பட வரைபடம்', nav_news: 'நீர்நிலை செய்திகள்', nav_track: 'புகாரைக் கண்காணி',
    nav_waterbodies: 'நீர்நிலைகள்', nav_about: 'எங்களைப் பற்றி', nav_faq: 'கேள்விகள்',
    page_dashboard: 'எனது புகார்கள்', page_track: 'புகாரைக் கண்காணி', page_waterbodies: 'நீர்நிலைகள்',
    page_news: 'சமீபத்திய நீர்நிலை செய்திகள்', page_about: 'எங்களைப் பற்றி', page_faq: 'அடிக்கடி கேட்கப்படும் கேள்விகள்',
    empty_reports: 'நீங்கள் இதுவரை எந்த புகாரும் சமர்ப்பிக்கவில்லை.',
    hero_tag: 'குடிமக்கள்–அரசு நீர் பாதுகாப்பு வலையமைப்பு',
    hero_h1_1: 'பார்க்கவும். புகாரளிக்கவும்.', hero_h1_2: 'பாதுகாக்கவும்.',
    hero_lead: 'குடிமக்களையும் அதிகாரிகளையும் இணைத்து உள்ளூர் நீர்நிலைகளைக் கண்காணிக்கவும், பாதுகாக்கவும், மீட்டெடுக்கவும் HydroSense உதவுகிறது.',
    cta_report: 'நீர் பிரச்சனையைப் புகாரளி', cta_explore: 'நீர்நிலைகளை ஆராயுங்கள்', cta_track: 'புகாரைக் கண்காணி',
    step1_t: 'கவனி', step1_d: 'குளம், ஏரி, ஆறு அல்லது தொட்டியில் தெரியும் பிரச்சனையை கவனிக்கவும்.',
    step2_t: 'புகாரளி', step2_d: 'புகைப்படம், இடம் மற்றும் நீங்கள் கண்டது — இரண்டு நிமிடங்கள்.',
    step3_t: 'உறுதிப்படுத்து', step3_d: 'அருகிலுள்ள குடிமக்கள் "நானும் இதைப் பார்க்கிறேன்" மூலம் உறுதிப்படுத்தலாம்.',
    step4_t: 'நடவடிக்கை', step4_d: 'அதிகாரிகள் ஆய்வு செய்து, நடவடிக்கை எடுத்து, முன்/பின் ஆவணப்படுத்துகிறார்கள்.',
    report_title: 'நீர்நிலை பிரச்சனையை புகாரளிக்கவும்',
    report_step1: '1 · நீர்நிலை', report_step2: '2 · புகைப்பட ஆதாரம்', report_step3: '3 · நீங்கள் கண்டது', report_step4: '4 · மதிப்பாய்வு & சமர்ப்பி',
    field_wb_type: 'நீர்நிலை வகை', field_wb_name: 'நீர்நிலை பெயர்', field_location: 'இடம்',
    field_use_location: '📍 எனது தற்போதைய இடத்தைப் பயன்படுத்து', field_address: 'தோராயமான முகவரி / அடையாளம் (விருப்பம்)',
    field_photos: 'புகைப்பட ஆதாரம்', field_observed: 'நீங்கள் என்ன கவனித்தீர்கள்? (பொருந்துவனவற்றைத் தேர்ந்தெடுக்கவும்)',
    field_notes: 'வேறு ஏதேனும் கவனித்தீர்களா?', field_anon: 'அநாமதேயமாக புகாரளி',
  },
};

function applyLang(lang) {
  localStorage.setItem('hs_lang', lang);
  document.documentElement.lang = lang;
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const key = el.getAttribute('data-i18n');
    if (DICT[lang][key]) el.textContent = DICT[lang][key];
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
    const key = el.getAttribute('data-i18n-placeholder');
    if (DICT[lang][key]) el.setAttribute('placeholder', DICT[lang][key]);
  });
  document.querySelectorAll('.lang-toggle button').forEach((b) => {
    const active = b.dataset.lang === lang;
    b.style.background = active ? 'rgba(255,255,255,0.18)' : 'transparent';
    b.style.fontWeight = active ? '700' : '400';
  });
}

document.addEventListener('DOMContentLoaded', () => {
  const saved = localStorage.getItem('hs_lang') || 'en';
  applyLang(saved);
  document.querySelectorAll('.lang-toggle button').forEach((b) => b.addEventListener('click', () => applyLang(b.dataset.lang)));
});

// Exposed so js/nav.js's site-wide language toggle button can drive translation
// on any page, not just pages with an inline .lang-toggle control.
window.hsApplyLanguage = applyLang;
