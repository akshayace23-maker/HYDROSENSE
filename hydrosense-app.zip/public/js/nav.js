// js/nav.js — fills the shared nav: auth CTA + theme toggle + language toggle (site-wide)
(function () {
  // --- Theme toggle (dark is default; already applied pre-paint by the inline head script) ---
  function currentTheme() { return localStorage.getItem('hs_theme') || 'dark'; }
  function setTheme(t) {
    localStorage.setItem('hs_theme', t);
    document.documentElement.setAttribute('data-theme', t);
    var btn = document.getElementById('themeToggleBtn');
    if (btn) btn.textContent = t === 'dark' ? '☀️ Light' : '🌙 Dark';
  }

  var navInner = document.querySelector('.nav__inner');
  if (navInner) {
    var controls = document.createElement('div');
    controls.className = 'nav__controls';
    controls.innerHTML = [
      '<button class="nav__icon-btn" id="themeToggleBtn" type="button" aria-label="Toggle dark/light theme"></button>',
      '<button class="nav__icon-btn" id="langToggleBtn" type="button" aria-label="Toggle Tamil/English">',
      (localStorage.getItem('hs_lang') === 'ta' ? 'EN' : 'த'),
      '</button>'
    ].join('');
    var ctaSlot = document.getElementById('navCta');
    if (ctaSlot) navInner.insertBefore(controls, ctaSlot);
    else navInner.appendChild(controls);

    document.getElementById('themeToggleBtn').addEventListener('click', function () {
      setTheme(currentTheme() === 'dark' ? 'light' : 'dark');
    });
    setTheme(currentTheme());

    document.getElementById('langToggleBtn').addEventListener('click', function () {
      var next = (localStorage.getItem('hs_lang') || 'en') === 'en' ? 'ta' : 'en';
      localStorage.setItem('hs_lang', next);
      if (window.hsApplyLanguage) window.hsApplyLanguage(next);
      document.getElementById('langToggleBtn').textContent = next === 'ta' ? 'EN' : 'த';
    });
  }

  // --- Auth-aware CTA (login / dashboard link) ---
  (async function () {
    var slot = document.getElementById('navCta');
    if (!slot) return;
    var user = await currentUser();
    if (!user) {
      slot.innerHTML = '<a class="btn btn-ghost btn-sm" href="/login.html">Log in</a>';
      return;
    }
    var dash = user.role === 'authority' ? '/authority-dashboard.html' : '/dashboard.html';
    slot.innerHTML =
      '<a class="btn btn-ghost btn-sm" href="' + dash + '">' + (user.role === 'authority' ? 'Authority dashboard' : 'My reports') + '</a>' +
      '<button class="btn btn-primary btn-sm" id="logoutBtn">Log out</button>';
    document.getElementById('logoutBtn').addEventListener('click', async function () {
      await api.post('/api/auth/logout');
      window.location.href = '/';
    });
  })();
})();
