// js/charts.js — tiny dependency-free SVG bar chart renderer
function svgBarChart(data, { width = 520, height = 180, color = '#0e8388', labelFmt = (x) => x } = {}) {
  if (!data.length) return '<p style="color:var(--ink-soft); font-size:0.85rem;">No data available yet.</p>';
  const max = Math.max(...data.map((d) => d.value), 1);
  const barW = Math.max(18, Math.floor((width - 20) / data.length) - 8);
  const gap = 8;
  let x = 10;
  const bars = data.map((d) => {
    const h = Math.round((d.value / max) * (height - 40));
    const bar = `<rect x="${x}" y="${height - 24 - h}" width="${barW}" height="${h}" rx="4" fill="${color}"></rect>
      <text x="${x + barW / 2}" y="${height - 24 - h - 6}" font-size="11" text-anchor="middle" fill="#0b2036">${d.value}</text>
      <text x="${x + barW / 2}" y="${height - 8}" font-size="10" text-anchor="middle" fill="#45607a">${labelFmt(d.label)}</text>`;
    x += barW + gap;
    return bar;
  }).join('');
  return `<svg viewBox="0 0 ${Math.max(width, x)} ${height}" style="width:100%; height:${height}px;">${bars}</svg>`;
}
